// export const slide = el => {
//   gsap.from(el, {
//     x: 100,
//     duration: 4
//   });
// };
